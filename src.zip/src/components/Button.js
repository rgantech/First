import React from 'react'


export default function Button(props) {
    return (
        <button type="button" onClick={props.funname} className="mx-2 my-3 btn btn-primary">title</button>
    )
}
